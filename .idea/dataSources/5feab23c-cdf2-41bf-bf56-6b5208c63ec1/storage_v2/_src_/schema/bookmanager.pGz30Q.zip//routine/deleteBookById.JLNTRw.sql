create
    definer = root@localhost procedure deleteBookById(IN inputIdBook int)
begin
    DELETE  FROM relative WHERE bookID= inputIdBook;
    delete from book where id = inputIdBook;
end;

