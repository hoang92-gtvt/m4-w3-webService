create
    definer = root@localhost procedure updateBook(IN inputId int, IN inputName varchar(50), IN inputPrice int)
BEGIN
    update book set  name = inputName, price = inputPrice where id= inputId;
end;

