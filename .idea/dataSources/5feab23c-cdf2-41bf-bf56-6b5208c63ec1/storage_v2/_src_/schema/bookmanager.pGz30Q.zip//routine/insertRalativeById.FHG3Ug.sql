create
    definer = root@localhost procedure insertRalativeById(IN bookId int, IN categoryId int)
begin
    insert into relative(bookID, categoryID) value (bookId,categoryId);
end;

