create
    definer = root@localhost procedure deleteRelativeById(IN inputId int)
BEGIN
    DELETE  FROM relative WHERE bookID= inputId;
END;

